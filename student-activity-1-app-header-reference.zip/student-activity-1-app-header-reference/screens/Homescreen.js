import * as React from 'react';
import { Text, View, TouchableOpacity, StyleSheet } from 'react-native';
import { Audio } from 'expo-av';
import AppHeader from '../components/AppHeader';

export default class Homescreen extends React.Component {
  gotoBuzzerscreen = (buzzerColor) => {
    this.props.navigation.navigate('Buzzerscreen', { color: buzzerColor });
  };
  render() {
    return (
      <View>
        <AppHeader />
        <TouchableOpacity
          style={[mystyle.teambtn, { backgroundColor: 'red' }]}
          onPress={() => this.gotoBuzzerscreen('red')}>
          <Text style={mystyle.teamtxt}>Go to Buzzer screen</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[mystyle.teambtn, { backgroundColor: 'blue' }]}
          onPress={() => this.gotoBuzzerscreen('blue')}>
          <Text style={mystyle.teamtxt}>Go to Buzzer screen</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[mystyle.teambtn, { backgroundColor: 'yellow' }]}
          onPress={() => this.gotoBuzzerscreen('yellow')}>
          <Text style={mystyle.teamtxt}>Go to Buzzer screen</Text>
        </TouchableOpacity>
      </View>
    );
  }
}
const mystyle = StyleSheet.create({
  teambtn: {
    marginLeft: 100,
    marginTop: 30,
    width: 150,
    height: 50,
    borderRadius: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  teamtxt: {
    color: 'black',
  },
});
